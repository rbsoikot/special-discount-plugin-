<?php
/*
Plugin Name: Special Discount Plugin
Description: A plugin to offer special discounts based on user purchase history, category, and specific product offers. Also integrates with Tutor LMS to automatically enroll users in courses upon purchase.
Version: 1.5
Author: Your Name
*/

// Add settings page in admin menu
add_action('admin_menu', 'special_discount_plugin_menu');
function special_discount_plugin_menu() {
    add_menu_page(
        'Special Discount Settings',
        'Special Discount',
        'manage_options',
        'special_discount_settings',
        'special_discount_settings_page',
        'dashicons-admin-generic',
        25
    );
}

function special_discount_settings_page() {
    if (isset($_POST['update_settings'])) {
        update_option('special_discount_categories', sanitize_text_field($_POST['discount_categories']));
        update_option('special_discount_values', sanitize_text_field($_POST['discount_values']));
        update_option('special_discount_products', sanitize_text_field($_POST['discount_products'])); // New field for specific products
        update_option('special_discount_product_values', sanitize_text_field($_POST['discount_product_values'])); // New field for specific product discount values
        update_option('special_discount_expiry', sanitize_text_field($_POST['discount_expiry'])); // New field for discount expiry time
        update_option('special_discount_additional_category', sanitize_text_field($_POST['discount_additional_category'])); // New field for additional category
        update_option('special_discount_new_user_products', sanitize_text_field($_POST['discount_new_user_products'])); // New field for new user products
        update_option('special_discount_new_user_values', sanitize_text_field($_POST['discount_new_user_values'])); // New field for new user discount values
        echo '<div class="updated"><p>Settings saved!</p></div>';
    }

    // Get current settings
    $categories = get_option('special_discount_categories', 'marketing,video-editing');
    $discount_values = get_option('special_discount_values', '50,30'); // Corresponding discount values for each category
    $discount_products = get_option('special_discount_products', ''); // Specific product offers
    $discount_product_values = get_option('special_discount_product_values', ''); // Specific product discount values
    $discount_expiry = get_option('special_discount_expiry', ''); // Discount expiry time
    $discount_additional_category = get_option('special_discount_additional_category', ''); // Additional category
    $discount_new_user_products = get_option('special_discount_new_user_products', ''); // New user products
    $discount_new_user_values = get_option('special_discount_new_user_values', ''); // New user discount values

    ?>
    <div class="wrap">
        <h1>Special Discount Settings</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th><label for="discount_categories">Eligible Categories</label></th>
                    <td><input type="text" name="discount_categories" id="discount_categories" value="<?php echo esc_attr($categories); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_values">Discount Values (comma-separated)</label></th>
                    <td><input type="text" name="discount_values" id="discount_values" value="<?php echo esc_attr($discount_values); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_products">Specific Product Offers (comma-separated product IDs)</label></th>
                    <td><input type="text" name="discount_products" id="discount_products" value="<?php echo esc_attr($discount_products); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_product_values">Specific Product Discount Values (comma-separated)</label></th>
                    <td><input type="text" name="discount_product_values" id="discount_product_values" value="<?php echo esc_attr($discount_product_values); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_expiry">Discount Expiry Time (YYYY-MM-DD HH:MM:SS)</label></th>
                    <td><input type="text" name="discount_expiry" id="discount_expiry" value="<?php echo esc_attr($discount_expiry); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_additional_category">Additional Category (optional)</label></th>
                    <td><input type="text" name="discount_additional_category" id="discount_additional_category" value="<?php echo esc_attr($discount_additional_category); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_new_user_products">New User Products (comma-separated product IDs)</label></th>
                    <td><input type="text" name="discount_new_user_products" id="discount_new_user_products" value="<?php echo esc_attr($discount_new_user_products); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th><label for="discount_new_user_values">New User Discount Values (comma-separated)</label></th>
                    <td><input type="text" name="discount_new_user_values" id="discount_new_user_values" value="<?php echo esc_attr($discount_new_user_values); ?>" class="regular-text" /></td>
                </tr>
            </table>
            <p><input type="submit" name="update_settings" class="button-primary" value="Save Settings" /></p>
        </form>
    </div>
    <?php
}

// Apply discount dynamically at checkout
add_action('woocommerce_cart_calculate_fees', 'apply_special_category_discount');

function apply_special_category_discount() {
    if (is_admin() && !defined('DOING_AJAX')) return;

    if (is_user_logged_in()) {
        $user_id = get_current_user_id();

        // Get the categories and discount details from the admin settings
        $eligible_categories = explode(',', get_option('special_discount_categories', 'marketing,video-editing'));
        $discount_values = explode(',', get_option('special_discount_values', '50,30')); // Corresponding discount values
        $discount_products = explode(',', get_option('special_discount_products', '')); // Specific product offers
        $discount_product_values = explode(',', get_option('special_discount_product_values', '')); // Specific product discount values
        $discount_new_user_products = explode(',', get_option('special_discount_new_user_products', '')); // New user products
        $discount_new_user_values = explode(',', get_option('special_discount_new_user_values', '')); // New user discount values

        $discount_amount = 0;

        foreach (WC()->cart->get_cart() as $cart_item) {
            $product_id = $cart_item['product_id'];
            $original_price = floatval($cart_item['data']->get_regular_price()); // Ensure it's a float
            $max_discount = 0; // Track the highest discount for this product

            // Check if the product belongs to the eligible categories
            foreach ($eligible_categories as $index => $category) {
                if (has_term($category, 'product_cat', $product_id)) {
                    // Check if the user qualifies for the discount
                    if (has_user_purchased_from_any_category($user_id, $eligible_categories)) {
                        $discount_value = floatval($discount_values[$index]); // Ensure it's a float
                        $max_discount = max($max_discount, $discount_value); // Track the highest discount
                    }
                }
            }

            // Check if the product is a specific product offer
            if (in_array($product_id, $discount_products)) {
                $product_index = array_search($product_id, $discount_products);
                $discount_value = floatval($discount_product_values[$product_index]); // Ensure it's a float
                $max_discount = max($max_discount, $discount_value); // Track the highest discount
            }

            // Check if the product is a new user offer
            if (in_array($product_id, $discount_new_user_products)) {
                $product_index = array_search($product_id, $discount_new_user_products);
                $discount_value = floatval($discount_new_user_values[$product_index]); // Ensure it's a float
                $max_discount = max($max_discount, $discount_value); // Track the highest discount
            }

            // Apply the highest discount for this product
            if ($max_discount > 0) {
                $discount = ($original_price * ($max_discount / 100)) * $cart_item['quantity'];
                $discount_amount += $discount;
            }
        }

        if ($discount_amount > 0) {
            WC()->cart->add_fee('Exclusive Discount', -$discount_amount, true);
        }
    }
}

// Restrict checkout access to eligible users
add_action('template_redirect', 'restrict_checkout_for_special_offer');

function restrict_checkout_for_special_offer() {
    if (is_checkout() && !is_user_logged_in()) {
        wp_redirect(home_url()); // Redirect guests to home
        exit;
    }

    if (is_checkout() && isset($_GET['add-to-cart'])) {
        $product_id = intval($_GET['add-to-cart']);
        $user_id = get_current_user_id();
        $eligible_categories = explode(',', get_option('special_discount_categories', 'marketing,video-editing'));
        $discount_new_user_products = explode(',', get_option('special_discount_new_user_products', '')); // New user products

        // Allow new users to purchase new user products
        if (in_array($product_id, $discount_new_user_products)) {
            return; // Do not redirect if the product is a new user offer
        }

        // Redirect non-eligible users for other products
        if (!has_user_purchased_from_any_category($user_id, $eligible_categories)) {
            wp_redirect(home_url()); // Redirect non-eligible users
            exit;
        }
    }
}

// Shortcode to display user's special offers with direct checkout
function special_offers_shortcode() {
    if (!is_user_logged_in()) {
        return '<p class="special-offers-message">Please log in to see your special offers.</p>';
    }

    $user_id = get_current_user_id();
    $eligible_categories = explode(',', get_option('special_discount_categories', 'marketing,video-editing'));
    $discount_products = explode(',', get_option('special_discount_products', '')); // Specific product offers
    $discount_product_values = explode(',', get_option('special_discount_product_values', '')); // Specific product discount values
    $discount_new_user_products = explode(',', get_option('special_discount_new_user_products', '')); // New user products
    $discount_new_user_values = explode(',', get_option('special_discount_new_user_values', '')); // New user discount values
    $discount_expiry = get_option('special_discount_expiry', ''); // Discount expiry time
    $discount_additional_category = get_option('special_discount_additional_category', ''); // Additional category
    $discounted_products = array();

    // Check if the discount has expired
    $current_time = current_time('timestamp');
    $expiry_time = strtotime($discount_expiry);

    if ($current_time > $expiry_time) {
        return '<p class="special-offers-message">No special offers available at the moment.</p>';
    }

    // Check if the user has any orders in "processing" status
    $processing_orders = wc_get_orders(array(
        'customer_id' => $user_id,
        'status' => 'processing',
        'limit' => -1
    ));

    // Check if the user has any completed orders
    $completed_orders = wc_get_orders(array(
        'customer_id' => $user_id,
        'status' => 'completed',
        'limit' => -1
    ));

    $has_processing_orders = !empty($processing_orders);
    $has_completed_orders = !empty($completed_orders);

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'tax_query' => array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $eligible_categories,
                'operator' => 'IN',
            ),
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $discount_additional_category,
                'operator' => 'IN',
            ),
        ),
        'post__in' => array_merge($discount_products, $discount_new_user_products), // Include specific product offers and new user products
    );

    $products = get_posts($args);

    foreach ($products as $product) {
        // If the user has processing orders but no completed orders, show new user offers
        if ($has_processing_orders && !$has_completed_orders && in_array($product->ID, $discount_new_user_products)) {
            $discounted_products[] = $product->ID;
        } 
        // If the user has completed orders, show all eligible offers
        elseif ($has_completed_orders) {
            if (has_user_purchased_from_any_category($user_id, $eligible_categories) || in_array($product->ID, $discount_new_user_products)) {
                $discounted_products[] = $product->ID;
            }
        }
    }

    $output = '<style>
        .special-offers-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .special-offers-title {
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 25px;
            color: #2c3e50;
        }
        .special-offers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .special-offer-card {
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            padding: 20px;
            border: 1px solid #e0e0e0;
        }
        .special-offer-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }
        .product-image img {
            width: 100%;
            height: auto;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .product-info h3 {
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        .product-info h3 a {
            color: inherit;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .product-info h3 a:hover {
            color: #0073aa;
        }
        .original-price {
            font-size: 16px;
            color: #888;
            text-decoration: line-through;
            margin-bottom: 5px;
        }
        .discounted-price {
            font-size: 24px;
            font-weight: 700;
            color: #e74c3c;
            margin-bottom: 20px;
        }
        .buy-now-button {
            display: inline-block;
            background: #4F338C;
            color: #fff;
            padding: 12px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .buy-now-button:hover {
            background: #4D3289;
        }
        .special-offers-message {
            text-align: center;
            font-size: 18px;
            color: #555;
            margin-top: 20px;
        }
        .countdown-timer {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            color: #e74c3c;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            .special-offers-grid {
                grid-template-columns: 1fr;
                padding: 10px;
            }
            .special-offers-title {
                font-size: 24px;
            }
            .special-offers-container {
                max-width: 100%;
                margin: 0 auto;
                padding: 10px;
            }
            .product-image img {
                width: 100%;
                height: 150px;
            }
        }
    </style>';

    if (!empty($discounted_products)) {
        $output .= '<div class="special-offers-container">
            <h2 class="special-offers-title">Your Exclusive Discount Offers</h2>
            <div class="countdown-timer" id="countdown-timer"></div>
            <div class="special-offers-grid">';

        foreach ($discounted_products as $product_id) {
            $product = wc_get_product($product_id);
            if ($product) {
                $original_price = floatval($product->get_regular_price()); // Ensure it's a float
                $discount_values = explode(',', get_option('special_discount_values', '50,30')); // Corresponding discount values

                $discounted_price = $original_price;

                // Get the discount value for each product's category
                foreach ($discount_values as $index => $discount_value) {
                    if (has_term($eligible_categories[$index], 'product_cat', $product_id)) {
                        $discount_value = floatval($discount_value); // Ensure it's a float
                        $discounted_price = ($original_price * (1 - $discount_value / 100));
                    }
                }

                // Check if the product is a specific product offer
                if (in_array($product_id, $discount_products)) {
                    $product_index = array_search($product_id, $discount_products);
                    $discount_value = floatval($discount_product_values[$product_index]); // Ensure it's a float
                    $discounted_price = ($original_price * (1 - $discount_value / 100));
                }

                // Check if the product is a new user offer
                if (in_array($product_id, $discount_new_user_products)) {
                    $product_index = array_search($product_id, $discount_new_user_products);
                    $discount_value = floatval($discount_new_user_values[$product_index]); // Ensure it's a float
                    $discounted_price = ($original_price * (1 - $discount_value / 100));
                }

                $checkout_url = wc_get_checkout_url() . '?add-to-cart=' . $product_id . '&apply_discount=1';

                $output .= '<div class="special-offer-card">
                    <a href="' . get_permalink($product_id) . '" class="product-image">
                        ' . get_the_post_thumbnail($product_id, 'medium') . '
                    </a>
                    <div class="product-info">
                        <h3><a href="' . get_permalink($product_id) . '">' . $product->get_name() . '</a></h3>
                        <p class="original-price"><strike>' . wc_price($original_price) . '</strike></p>
                        <p class="discounted-price">' . wc_price($discounted_price) . '</p>
                        <a href="' . esc_url($checkout_url) . '" class="buy-now-button">Buy Now</a>
                    </div>
                </div>';
            }
        }

        $output .= '</div></div>';

        // Add JavaScript for countdown timer
        $output .= '<script>
            var countdownDate = new Date("' . esc_js($discount_expiry) . '").getTime();

            var countdownTimer = setInterval(function() {
                var now = new Date().getTime();
                var distance = countdownDate - now;

                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                document.getElementById("countdown-timer").innerHTML = "Time left: " + days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

                if (distance < 0) {
                    clearInterval(countdownTimer);
                    document.getElementById("countdown-timer").innerHTML = "Offer Expired";
                    document.querySelector(".special-offers-grid").innerHTML = "<p class=\'special-offers-message\'>No special offers available at the moment.</p>";
                }
            }, 1000);
        </script>';
    } else {
        $output .= '<p class="special-offers-message">No special offers available at the moment.</p>';
    }

    return $output;
}
add_shortcode('special_offers', 'special_offers_shortcode');

// Function to check if the user has purchased from any eligible category
function has_user_purchased_from_any_category($user_id, $category_slugs) {
    if (!$user_id) return false;

    $orders = wc_get_orders(array(
        'customer_id' => $user_id,
        'status' => array('completed', 'processing'),
        'limit' => -1
    ));

    foreach ($orders as $order) {
        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            foreach ($category_slugs as $category_slug) {
                if (has_term($category_slug, 'product_cat', $product_id)) {
                    return true; // User has purchased from at least one category
                }
            }
        }
    }

    return false;
}

// Hook into WooCommerce order completion to enroll user in Tutor LMS course
add_action('woocommerce_order_status_completed', 'enroll_user_in_tutor_course', 10, 1);

function enroll_user_in_tutor_course($order_id) {
    $order = wc_get_order($order_id);
    $user_id = $order->get_user_id();

    if (!$user_id) {
        return; // Exit if no user ID is found
    }

    foreach ($order->get_items() as $item) {
        $product_id = $item->get_product_id();
        $course_id = get_post_meta($product_id, '_tutor_course_id', true);

        if ($course_id) {
            // Enroll the user in the Tutor LMS course
            try {
                tutor_utils()->do_enroll($course_id, $user_id);
            } catch (Exception $e) {
                // Log the error or handle it as needed
                error_log('Error enrolling user in course: ' . $e->getMessage());
            }
        }
    }
}